#! /bin/sh
sudo mv dwl-v0.4/dwl /usr/local/bin/dwl
