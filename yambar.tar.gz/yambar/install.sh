#! /bin/sh

sudo mv yambar $HOME/.config
