#! /bin/sh

mv ./gtkrc-2.0 /home/${USER}/.gtkrc-2.0
if [ ! -d "/usr/share/themes"]
then         
        mkdir /usr/share/themes
fi
mv ./Breeze-dark-gtk /usr/share/themes/Breeze-dark-gtk

