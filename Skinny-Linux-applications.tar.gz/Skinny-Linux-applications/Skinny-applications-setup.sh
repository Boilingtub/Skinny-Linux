#! /bin/sh

mv ./alsamixer.desktop       /usr/share/applications/alsamixer.desktop
mv ./Shutdown.desktop        /usr/share/applications/Shutdown.desktop
mv ./Restart.desktop         /usr/share/applications/Restart.desktop
mv ./Run-In-Terminal.desktop /usr/share/applications/Run-In-Terminal.desktop
mv ./Terminal.desktop        /usr/share/applications/Terminal.desktop
mv ./lua.desktop             /usr/share/applications/lua.desktop
mv ./Shutdown.directory      /usr/share/desktop-directories/Shutdown.directory
mv ./lxde-applications.menu  /etc/xdg/menus/lxde-applications.menus
mv ./libfm.conf              /home/${USER}/.config/libfm/libfm.conf
