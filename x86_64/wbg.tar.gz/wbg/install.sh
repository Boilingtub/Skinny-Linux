#! /bin/sh
mv wbg/wallpaper /usr/local/bin
mv wbg/wbg /usr/local/bin
mv wbg/libjpeg/libjpeg.a /lib
mv wbg/libjpeg/libjpeg.so /lib
mv wbg/libjpeg/libjpeg.so.62 /lib
mv wbg/libjpeg/libjpeg.so.62.3.0 /lib
