#! /bin/sh
mv dwl-v0.5/dwl /usr/local/bin/
