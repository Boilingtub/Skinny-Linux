#! /bin/sh
echo "installed FontAwesome through xbps"
