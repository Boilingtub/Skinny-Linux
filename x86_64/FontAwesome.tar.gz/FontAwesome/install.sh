#! /bin/sh
mv FontAwesome /usr/share/fonts/OTF 
