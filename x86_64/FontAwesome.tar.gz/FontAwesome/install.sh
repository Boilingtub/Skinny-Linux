#! /bin/sh
sudo mv FontAwesome /usr/share/fonts/OTF 
