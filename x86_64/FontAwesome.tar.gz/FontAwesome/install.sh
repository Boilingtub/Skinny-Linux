#! /bin/sh
sudo mv FontAwesome/FontAwesome /usr/share/fonts/OTF 
