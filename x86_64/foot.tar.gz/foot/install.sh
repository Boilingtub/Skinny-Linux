#! /bin/sh
mv foot $HOME/.config
