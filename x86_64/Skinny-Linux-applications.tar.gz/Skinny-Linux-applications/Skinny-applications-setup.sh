#! /bin/sh

if [ ! -d "/usr/share/applications/" ]
then
     mkdir "/usr/share/applications"
fi

mv ./Skinny-Linux-applications/alsamixer.desktop       /usr/share/applications/alsamixer.desktop
mv ./Skinny-Linux-applications/Shutdown.desktop        /usr/share/applications/Shutdown.desktop
mv ./Skinny-Linux-applications/Restart.desktop         /usr/share/applications/Restart.desktop
mv ./Skinny-Linux-applications/Run-In-Terminal.desktop /usr/share/applications/Run-In-Terminal.desktop
mv ./Skinny-Linux-applications/Terminal.desktop        /usr/share/applications/Terminal.desktop
mv ./Skinny-Linux-applications/lua.desktop             /usr/share/applications/lua.desktop
mv ./Skinny-Linux-applications/Shutdown.directory      /usr/share/desktop-directories/Shutdown.directory
mv ./Skinny-Linux-applications/lxde-applications.menu  /etc/xdg/menus/lxde-applications.menus

if [ ! -d "/home/${USER}/.config" ]
then
    mkdir "/home/${USER}/.config"
    chown -R ${USER} "/home/${USER}/.config"
fi

if [ ! -d "/home/${USER}/.config/libfm" ]
then
     mkdir "/home/${USER}/.config/libfm"
     chown -R ${USER} "/home/${USER}/.config/libfm"
fi

mv ./Skinny-Linux-applications/libfm.conf              /home/${USER}/.config/libfm/libfm.conf
