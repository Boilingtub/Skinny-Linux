#! /bin/sh

if [ ! -d "/usr/share/applications/" ]
then
     mkdir "/usr/share/applications"
fi

mv ./Skinny-Linux-appmenu/alsamixer.desktop       /usr/share/applications/alsamixer.desktop
mv ./Skinny-Linux-appmenu/Shutdown.desktop        /usr/share/applications/Shutdown.desktop
mv ./Skinny-Linux-appmenu/Restart.desktop         /usr/share/applications/Restart.desktop
mv ./Skinny-Linux-appmenu/Run-In-Terminal.desktop /usr/share/applications/Run-In-Terminal.desktop
mv ./Skinny-Linux-appmenu/Terminal.desktop        /usr/share/applications/Terminal.desktop
mv ./Skinny-Linux-appmenu/lua.desktop             /usr/share/applications/lua.desktop
mv ./Skinny-Linux-appmenu/Shutdown.directory      /usr/share/desktop-directories/Shutdown.directory
mv ./Skinny-Linux-appmenu/lxde-applications.menu  /etc/xdg/menus/lxde-applications.menus

if [ ! -d "/home/${USER}/.config" ]
then
    mkdir "/home/${USER}/.config"
    chown -R ${USER} "/home/${USER}/.config"
fi

if [ ! -d "/home/${USER}/.config/libfm" ]
then
     mkdir "/home/${USER}/.config/libfm"
     chown -R ${USER} "/home/${USER}/.config/libfm"
fi

mv ./Skinny-Linux-applications/libfm.conf              /home/${USER}/.config/libfm/libfm.conf

#=========// Icons \\ =========#

if [ ! -d "/usr/share/icons" ]
then
        mkdir "/usr/share/icons"
        chown -R ${USER} "/usr/share/icons"
fi

mv ./Skinny-Linux-appmenu/alsamixer-icon.png     /usr/share/icons/alsamixer-icon.png
mv ./Skinny-Linux-appmenu/Restart-icon.png       /usr/share/icons/Restart-icon.png
mv ./Skinny-Linux-appmenu/Shutdown-icon.png      /usr/share/icons/Shutdown-icon.png
mv ./Skinny-Linux-appmenu/terminal-icon.png      /usr/share/icons/terminal-icon.png
mv ./Skinny-Linux-appmenu/root-terminal-icon.png /usr/share/icons/root-terminal-icon.png
mv ./Skinny-Linux-appmenu/lua-icon.svg           /usr/share/icons/lua-icon.svg

