#! /bin/sh

mv ./Wayland-Software-Setup/dwl /usr/local/bin/dwl
mv ./Wayland-Software-Setup/somebar /usr/local/bin/somebar 
mv ./Wayland-Software-Setup/someblocks /usr/local/bin/someblocks 
mv ./Wayland-Software-Setup/wgb /usr/local/bin/wbg
mv ./Wayland-Software-Setup/wallpaper-wbg /usr/local/bin/wallpaper-wbg

if [ $USER != "root" ] ; then
   echo "dwl -s \"somebar | someblocks | wbg $HOME/.wallpaper\"" >> /home${USER}/.profile
fi
