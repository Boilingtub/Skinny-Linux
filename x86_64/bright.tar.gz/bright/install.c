#! /bin/sh
mv bright/bright /usr/local/bin/bright
