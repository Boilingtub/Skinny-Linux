#! /bin/sh
mv wlr-randr/wlr-randr /usr/local/bin/wlr-randr
