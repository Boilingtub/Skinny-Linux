#! /bin/sh

mv yambar $HOME/.config
