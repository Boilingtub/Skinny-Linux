#! /bin/sh
mv kickoff/kickoff /usr/local/bin
mv kickoff $HOME/.config
