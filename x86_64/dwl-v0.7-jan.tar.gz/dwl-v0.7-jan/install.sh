#! /bin/sh
sudo mv dwl-v0.7-jan/dwl /usr/local/bin/dwl
