#! /bin/sh

mv ./Suckless-Software/dwm /usr/local/bin/dwm
mv ./Suckless-Software/st /usr/local/bin/st
mv ./Suckless-Software/dmenu /usr/local/bin/dmenu
mv ./Suckless-Software/dmenu_run /usr/local/bin/dmenu_run
mv ./Suckless-Software/dmenu_path /usr/local/bin/dmenu_path
mv ./Suckless-Software/stest /usr/local/bin/stest
mv ./Suckless-Software/wallpaper /usr/local/bin/wallpaper

if [ $USER != "root" ] ; then
rm /home/${USER}/.xinitrc
echo "while true; do\nxsetroot -name "$( date +"%F %R" )"\nsleep 1m\ndone & \n wallpaper -reload\nexec dwm" >> /home/${USER}/.xinitrc
echo "TERM=xterm" >> /home/${USER}/.bashrc
echo "if [[ \"$(tty)\" == \"/dev/tty1\" ]]\nthen\n        startx\nfi" >> /home/${USER}/.profile
fi
