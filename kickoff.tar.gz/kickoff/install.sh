#! /bin/sh
sudo mv kickoff/kickoff /usr/local/bin
mv kickoff $HOME/.config
