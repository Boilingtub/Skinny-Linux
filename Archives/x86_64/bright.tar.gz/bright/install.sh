#! /bin/sh
sudo mv bright/bright /usr/local/bin/bright
