#! /bin/sh
sudo mv slstatus/slstatus /usr/local/bin/slstatus
