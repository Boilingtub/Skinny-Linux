require "nvchad.options"

-- add yours here!
vim.cmd("set linebreak")
vim.cmd("set wrap")
vim.cmd("set textwidth=80")
-- local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
