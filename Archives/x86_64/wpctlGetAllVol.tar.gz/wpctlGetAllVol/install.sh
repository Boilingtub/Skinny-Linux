#! /bin/sh
sudo mv wpctlGetAllVol/wpctlGetAllVol /usr/local/bin/
