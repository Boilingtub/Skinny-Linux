#! /bin/sh
sudo mv foot $HOME/.config
