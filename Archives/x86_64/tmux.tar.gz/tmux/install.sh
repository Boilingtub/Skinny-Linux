#! /bin/sh
sudo mv tmux $HOME/.config
