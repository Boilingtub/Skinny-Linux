#! /bin/sh
sudo mv wbg/wallpaper /usr/local/bin
sudo mv wbg/wbg /usr/local/bin
sudo mv wbg/libjpeg/libjpeg.a /lib
sudo mv wbg/libjpeg/libjpeg.so /lib
sudo mv wbg/libjpeg/libjpeg.so.62 /lib
sudo mv wbg/libjpeg/libjpeg.so.62.3.0 /lib
