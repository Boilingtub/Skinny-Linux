#! /bin/sh
sudo mv dwl-v0.7-patched-base/dwl /usr/local/bin/dwl
