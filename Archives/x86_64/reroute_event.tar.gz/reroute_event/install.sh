#! /bin/sh
sudo mv reroute_event/reroute_event /usr/local/bin/reroute_event
sudo mv reroute_event/toggle_touch_pad.sh ~/.local/bin/
