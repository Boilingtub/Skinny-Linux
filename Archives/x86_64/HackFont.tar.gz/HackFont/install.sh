#! /bin/sh
sudo mv HackFont/HackFont/HackNerdFont-Bold.ttf
sudo mv HackFont/HackFont/HackNerdFontMono-Bold.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontPropo-Bold.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFont-BoldItalic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontMono-BoldItalic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontPropo-BoldItalic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFont-Italic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontMono-Italic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontPropo-Italic.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFont-Regular.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontMono-Regular.ttf /usr/share/fonts/TTF 
sudo mv HackFont/HackFont/HackNerdFontPropo-Regular.ttf /usr/share/fonts/TTF 
