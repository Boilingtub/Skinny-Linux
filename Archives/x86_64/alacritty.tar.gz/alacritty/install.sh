#! /bin/sh
sudo mv alacritty $HOME/.config
