setfont /usr/share/kbd/consolefonts/ter-128b
