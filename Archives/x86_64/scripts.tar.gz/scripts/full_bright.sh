#!/bin/sh
echo "jan" | sudo -S bright 100
