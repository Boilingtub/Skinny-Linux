slstatus -s | dbus-run-session dwl
