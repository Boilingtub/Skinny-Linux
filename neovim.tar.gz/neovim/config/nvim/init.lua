vim.cmd "set number"
vim.cmd "syntax on"
vim.cmd "set tabstop=4"
vim.cmd "set shiftwidth=4"
vim.cmd "set expandtab"
vim.cmd "set termguicolors"
vim.cmd "set background=dark"
--vim.cmd "colorscheme carbonfox"
--vim.cmd "let g:lightline = { 'colorscheme': 'midnight' }"
vim.g.moonflyCursorColor = true
vim.cmd "colorscheme moonfly"

vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
vim.opt.termguicolors = true


require('plugins')
require('keymaps')

