vim.cmd "set number"
vim.cmd "syntax on"
vim.cmd "set expandtab"
require('plugins')
require('keymaps')
