vim.cmd "set number"
vim.cmd "syntax on"
vim.cmd "set expandtab"
vim.cmd "colorscheme desert"
require('plugins')
require('keymaps')
