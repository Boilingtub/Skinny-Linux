#! /bin/sh

mv ./local/nvim   /home/${USER}/.local/share/nvim
mv ./config/nvim  /home/${USER}/.config/nvim
