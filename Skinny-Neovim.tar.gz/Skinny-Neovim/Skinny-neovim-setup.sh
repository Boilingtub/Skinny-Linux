#! /bin/sh

mkdir -p "/home/${USER}/.local/share"
mv ./Skinny-Neovim/local/nvim   /home/${USER}/.local/share/nvim
mkdir -p "/home/${USER}/.config"
mv ./Skinny-Neovim/config/nvim  /home/${USER}/.config/nvim
