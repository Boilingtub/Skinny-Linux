#! /bin/sh

mkdir -p "/home/${USER}/.local/share"
mv -r ./Skinny-Neovim/local/nvim   /home/${USER}/.local/share/nvim
mkdir -p "/home/${USER}/.config"
mv -r ./Skinny-Neovim/config/nvim  /home/${USER}/.config/nvim
