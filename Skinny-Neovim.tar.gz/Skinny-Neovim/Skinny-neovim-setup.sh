#! /bin/sh

if [ ! -d "/home/${USER}/.local" ]
then
     mkdir "/home/${USER}/.local"
     chown -R ${USER} "/home/${USER}/.local"
fi

if [ ! -d "/home/${USER}/.local/share" ]
then
     mkdir "/home/${USER}/.local/share"
     chown -R ${USER} "/home/${USER}/.local/share"
fi

mv ./Skinny-Neovim/local/nvim   /home/${USER}/.local/share/nvim

if [ ! -d "/home/${USER}/.config" ]
then
     mkdir "/home/${USER}/.config"
     chown -R ${USER} "/home/${USER}/.config"

fi

mv ./Skinny-Neovim/config/nvim  /home/${USER}/.config/nvim
