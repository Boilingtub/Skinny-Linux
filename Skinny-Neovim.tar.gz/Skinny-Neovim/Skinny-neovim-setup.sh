#! /bin/sh

mv ./Skinny-Neovim/local/nvim   /home/${USER}/.local/share/nvim
mv ./Skinny-Neovim/config/nvim  /home/${USER}/.config/nvim
