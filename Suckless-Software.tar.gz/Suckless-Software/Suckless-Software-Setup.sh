#! /bin/sh

mv ./dwm /usr/local/bin/dwm
mv ./st /usr/local/bin/st
mv ./dmenu /usr/local/bin/dmenu
mv ./dmenu_run /usr/local/bin/dmenu_run
mv ./dmenu_path /usr/local/bin/dmenu_path
mv ./stest /usr/local/bin/stest

if [ $USER != "root" ] ; then
rm /home/${USER}/.xinitrc
echo "while true; do\nxsetroot -name "$( date +"%F %R" )"\nsleep 1m\ndone &\nexec dwm" >> /home/${USER}/.xinitrc
echo "TERM=xterm" >> /home/${USER}/.bashrc
echo "if [[ \"$(tty)\" == \"/dev/tty1\" ]]\nthen\n        startx\nfi" >> /home/${USER}/.profile
fi
